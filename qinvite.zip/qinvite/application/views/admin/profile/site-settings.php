<?php
    $this->load->view('admin/inc/header');
    $this->load->view('admin/inc/sidebar');
?>
<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Site Settings</h1>
</div>

<!-- Content Row -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header">Site settings</div>
            <div class="card-body">
                <?php 
                    if($this->session->flashdata("errors")){
                        echo '<div class="alert alert-danger text-center">'.$this->session->flashdata("errors").'</div>';
                    }elseif($this->session->flashdata('success')){
                        echo '<div class="alert alert-success text-center">'.$this->session->flashdata("success").'</div>';
                    }
                  
                ?>
                <form method="post" action="" enctype="multipart/form-data">

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="small mb-1" for="inputsite_title">Title</label>
                            <input class="form-control" name="site_title" id="inputsite_title" type="text" required value="<?=$site_title?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="small mb-1" for="inputsite_desc">Description</label>
                            <input class="form-control" name="site_desc" id="inputsite_desc" type="text" required value="<?=$site_desc?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="small mb-1" for="inputmeta_tags">Meta tags</label>
                            <input class="form-control" name="meta_tags" id="inputmeta_tags" type="text" required value="<?=$meta_tags?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="small mb-1" for="inputmeta_desc">Meta description</label>
                            <textarea class="form-control" name="meta_desc" id="inputmeta_desc" required><?=$meta_desc?></textarea>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label class="small mb-1" for="inputreceptionist_price">Receptionist Price (QR)</label>
                            <input class="form-control" name="receptionist_price" id="inputreceptionist_price" type="number" min=1 required value="<?=$receptionist_price?>">
                        </div>
                    </div>
                    <!-- Save changes button-->
                    <button class="btn btn-primary" type="submit">Save changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    $this->load->view('admin/inc/footer');