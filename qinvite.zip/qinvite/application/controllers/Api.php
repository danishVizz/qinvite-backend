<?php

require APPPATH . 'libraries/REST_Controller.php';


class Api extends REST_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->model('api_model');
    }

    function preview($data){
        echo '<pre>'; print_r($data);exit;
    }

    function search_get(){
        $keyword = $this->db->escape_str($this->input->get('keyword'));
        $data = $this->api_model->search($keyword);
        $events = $data['data'];
        foreach($events as $event){
            $receptionists = $this->api_model->get_event_receptionists($event->id);
            if($receptionists){
                $event->receptionists = $receptionists;
            }         
        }

        $data['data'] = $events;
        $this->set_response($data, REST_Controller::HTTP_OK);
    }


    // ================= Users APIs ===================

    public function signup_post(){

        
        $cnic = $this->input->post('cnic');
        $password = $this->input->post('password');
        $phone = $this->input->post('phone');
        $email = $this->input->post('email');
        
        $errors = "";
        if($email){
            $errors .= ((!filter_var($email,FILTER_VALIDATE_EMAIL)) ? "Invalid Email" : "");
        }
        $errors .= ((strlen($password) < 6) ? "Password length must not be less than 6" : "");

        if($errors ==""){
            if($this->api_model->check_existance('users',['username'=> $cnic])){
                $res = $this->api_model->response(false, [], 'User already exists!');
                $this->set_response($res, REST_Controller::HTTP_NOT_FOUND);
            }else{
                $data = array(
                    'username' => $this->db->escape_str($cnic),
                    'password' => md5($password),
                    'phone' => $this->db->escape_str($phone),
                    'email' => $this->db->escape_str($email),
                    'role' => 2,
                    'status' => 0
                );

                $res = $this->api_model->add_user($data);
        
                $this->set_response($res, REST_Controller::HTTP_OK);
            }
        }else{
            $err = $this->api_model->response(false, [], $errors);
            $this->set_response($err, REST_Controller::HTTP_OK);
        }

       
    }

    public function get_user_get(){
        $user_id = $this->input->get('user_id');
        $data = ['id' => $this->db->escape_str($user_id)];

        $res = $this->api_model->get_user($data);
        $this->set_response($res, REST_Controller::HTTP_OK);
    }


    public function login_post(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if($username && $password ){
            $data = array(
                'username' => $this->db->escape_str($username),
                'password' => md5($password)
            );

            $res = $this->api_model->login_user($data);
            $this->set_response($res, REST_Controller::HTTP_OK);
        }else{
            $this->set_response("invalid details", REST_Controller::HTTP_OK);
        }
    }

    public function update_user_post(){

        $user_id  = $this->db->escape_str($this->input->post('user_id'));
        $cnic = $this->input->post('cnic');
        $first_name = $this->input->post('firstname');
        $last_name = $this->input->post('lastname');
        $phone = $this->input->post('phone');
        $email = $this->input->post('email');
        $city = $this->input->post('city');
        $country = $this->input->post('country');
        $img = false;
        if(isset($_FILES["user_image"])){
            $file = $_FILES["user_image"];
            $filename = $file["name"];
            $file_name_split = explode(".",$filename);
            $ext = end($file_name_split);
            $allowed_ext = array("jpg","png","jpeg","gif");
            
            if(in_array($ext,$allowed_ext)){
                $img = $this->upload_img($file,"images/user_img");
            }
        }
        $errors = "";
        if($email){
            $errors .=((!filter_var($email, FILTER_VALIDATE_EMAIL)) ? "Invalid Email address!<br>" : "" );
        }

        if($errors){

            $err = $this->api_model->response(false, [], $errors);
            $this->set_response($err, REST_Controller::HTTP_OK);

        }else{

            $data = array(
                'first_name' => $this->db->escape_str($first_name),
                'last_name' => $this->db->escape_str($last_name),
                'phone' => $this->db->escape_str($phone),
                'email' => $this->db->escape_str($email),
                'city' => $this->db->escape_str($city),
                'country' => $this->db->escape_str($country)
            );
            if($img){
                $data["user_image"] = $img;
            }
    
            $res = $this->api_model->update_user(['id' => $user_id], $data);
            $this->set_response($res, REST_Controller::HTTP_OK);
        }
       
    }


    public function delete_user_delete($id){
        $res = $this->api_model->delete_user($id);
        $this->set_response($res, REST_Controller::HTTP_OK);
    }

    // ================= Designer APIs ===================

    
    public function get_designers_get(){
        $designers = $this->api_model->get_designers();
        $this->set_response($designers, REST_Controller::HTTP_OK);
    }

    public function request_designer_post(){
        $designer_id = $this->db->escape_str($this->input->post('designer_id'));
        $event_id = $this->db->escape_str($this->input->post('event_id'));
        $user_id = $this->db->escape_str($this->input->post('user_id'));
        $data = [
            'designer_id' => $designer_id,
            'event_id'  => $event_id,
            'user_id' => $user_id,
            'dated' => date('Y-m-d H:i:s'),
            'design_status'    => 0,
        ];

        $res = $this->api_model->request_designer($data);

        $this->set_response($res, REST_Controller::HTTP_OK);
    }


    // ================= Packages APIs ===================

    public function get_packages_get(){
        $user_id = $this->input->get('user_id');
        $data = $this->api_model->get_packages(['user_id' => $user_id]);
        $this->set_response($data, REST_Controller::HTTP_OK);
    }

    public function validate_package($pkg_name, $discount_code){
        // $pkg_name = $this->db->escape_str($this->input->post('package_name'));
        // $discount_code = $this->db->escape_str($this->input->post('discount_code'));

        $errors = "";
        if($discount_code){
            $errors .= (!$this->api_model->check_existance('promo_codes', ['code' => $discount_code,'status' => 0])) ? "Invalid promo code" : "";
        }
        $errors .=($this->api_model->check_existance('packages', ['package_name' => $pkg_name])) ? "Package name already taken" : "";

        if(!$errors){
            $res = [
                'status' => true,
                'data' => [],
                'message' => 'Package is valid'
            ];
        }else{
            $res = [
                'status' => false,
                'data' => [],
                'message' => $errors
            ];
            
        }
        return $res;
        //$this->set_response($res, REST_Controller::HTTP_OK);

    }

    public function add_package_post(){
        $package_name = $this->input->post('package_name');
        $discount_code = $this->input->post('discount_code');
        $no_of_people = $this->input->post('no_of_people');
        $user_id = $this->input->post('user_id');
        $price_per_qr = $this->api_model->get_price();
        $pkg_price = ($price_per_qr * $no_of_people);

        $validate_package = $this->validate_package($package_name, $discount_code);
        if($validate_package['status']){
            $pkg_array = array(
                'package_name' => $this->db->escape_str($package_name),
                'package_price' => $this->db->escape_str($pkg_price),
                'package_people' => $this->db->escape_str($no_of_people),
                'package_type' => 1,
                'user_id' => $this->db->escape_str($user_id),
                'promo_code' => $this->db->escape_str($discount_code)
            );  
            $package_id = $this->api_model->add_package($pkg_array);
            if($discount_code){
                $res = $this->api_model->update_promocode(['status' => 1, 'package_id' => $package_id], ['code' => $discount_code]);
            }
            $this->set_response($res, REST_Controller::HTTP_OK);
        }else{
            $this->set_response($validate_package, REST_Controller::HTTP_OK);
        }       

    }


    // ================= Events APIs ===================

    public function add_event_post(){ 

        ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

        $user_id = $this->input->post('user_id');
        $event_name = $this->input->post('event_name');
        $event_date = $this->input->post('event_date');
        $event_address = $this->input->post('event_address');
        $package_id = $this->db->escape_str($this->input->post('package_id'));
        $no_of_receptionists = $this->db->escape_str($this->input->post('no_of_receptionists'));
        $categories = $this->input->post('categories');
        $receptionists = $this->input->post('receptionists');
        $img = false;
        if(isset($_FILES["event_card"])){
            $file = $_FILES["event_card"];
            $filename = $file["name"];
            $file_name_split = explode(".",$filename);
            $ext = end($file_name_split);
            $allowed_ext = array("jpg","png","jpeg","gif");
            
            if(in_array($ext,$allowed_ext)){
                $img = $this->upload_img($file,"images/");
            }
        }
        $errors = "";
        $errors .= (!$this->api_model->check_existance('users', ['id' => $user_id]) ? 'Invalid user' : "");
        
        if(!$errors){
            $data = array(
                'user_id' => $this->db->escape_str($user_id),
                'event_name' => $this->db->escape_str($event_name),
                'package_id' => $package_id,
                'event_date' => $this->db->escape_str($event_date),
                'event_address' => $this->db->escape_str($event_address),
                'no_of_receptionists' => $no_of_receptionists,
                'event_status' => 0
            );
            if($img){
                $data["event_card"] = $img;
            }
    
            $event_id = $this->api_model->add_event($data);
            if($event_id){
                $this->api_model->add_receptionists($event_id, $receptionists);

                for($i =0; $i < count($categories); $i++){
                    $data = [
                        'event_id' => $event_id,
                        'category_id' => $categories[$i]
                    ];
                    $res = $this->api_model->add_event_category($data);
                }                
            }
        }else{
            $res = [
                'status' => true,
                'data'  => [],
                'message' => $errors
            ];
        }

        $this->set_response($res, REST_Controller::HTTP_OK);
    } 

    public function get_events_get(){

        $user_id = $this->input->get('user_id');
        $data = [ 'user_id' => $this->db->escape_str($user_id)];

        $data = $this->api_model->get_events($data);
        $events = $data['data'];
        foreach($events as $event){
            $receptionists = $this->api_model->get_event_receptionists($event->id);
            if($receptionists){
                $event->receptionists = $receptionists;
            }         

            $package = $this->api_model->get_event_package(['id' => $event->package_id]);
            if($package){
                $event->package_details = $package;
            }

            $participants = $this->api_model->get_participants(['event_id' => $event->id]);
            if($participants){
                $event->participants = $participants;
            }
        }

        $data['data'] = $events;
        
        //echo '<pre>';print_r($data['data']);exit;

        
        $this->set_response($data, REST_Controller::HTTP_OK);
    }

    public function edit_event_post(){
        $event_id = $this->input->post('event_id');
        $event_name = $this->input->post('event_name');
        $event_date = $this->input->post('event_date');
        $event_address = $this->input->post('event_address');
        $event_package = $this->input->post('event_package');
        $no_of_receptionists = $this->db->escape_str($this->input->post('no_of_receptionists'));
        $receptionists = $this->input->post('receptionists');
        
        
        $data = [
            'event_name' => $this->db->escape_str($event_name),
            'event_address' => $this->db->escape_str($event_address),
            'event_date' => $event_date,
            'no_of_receptionists' => $no_of_receptionists
        ];

        if($event_package){
            $data['package_name'] = $this->db->escape_str($event_package);
        }

        $res = $this->api_model->edit_event($data, $this->db->escape_str($event_id));
        if($res && $receptionists){
            $res = $this->api_model->update_receptionist($event_id, $receptionists);
        }
        $this->set_response($res, REST_Controller::HTTP_OK);
    }
    
    public function delete_event_delete($id){
        $res = $this->api_model->delete_event($this->db->escape_str($id));
        $this->set_response($res, REST_Controller::HTTP_OK);
    }
    

    // ================= Category APIs ===================

    public function add_category_post(){
        $category_name = $this->input->post('category_name');
        $phones = $this->db->escape_str($this->input->post('phones'));
        $people_per_qr = $this->input->post('no_of_qr');
        $participants = $this->input->post('participants');
        $user_id = $this->input->post('user_id');
        //$event_id = $this->db->escape_str($this->input->post('event_id'));
        // $phones = $this->db->escape_str($phones);
        //$this->preview($participants);
        
        


        $data = [
            'name' => $this->db->escape_str($category_name),
            'people_per_qr' => $this->db->escape_str($people_per_qr),
            'user_id' => $user_id,
            'type' => 1,
            'phones' => ($phones === 'allowed' ? 1: 0)
        ];
        
        $category_id = $this->api_model->add_category($data);

        if($category_id){  
            $participants = json_decode($participants,true);
            for($x=0;$x<count($participants);$x++){
                $participant = json_decode($participants[$x],true);
                //$participant['event_id'] = $event_id;
                $participant['category_id'] = $category_id;
                $participant_id = $this->api_model->add_participant($participant);
                $data = $this->api_model->get_participants(['id' => $participant_id]);
                $qr_path = $this->qr_code_model($data[0]);
                //$this->preview($data);
                $participant['qr_img'] = $qr_path;
                //$this->preview($participant);

            }
            $res = [
                'status' => false,
                'data' => [],
                'message' => 'Category added successfully'
            ];
        }else{
            $res = [
                'status' => false,
                'data' => [],
                'message' => 'something went wrong'
            ];
        }
        // $this->db->insert('temp', ['content' => json_encode($participants)]);
        // $tempdata = $this->db->get('temp')->result();
        // $this->preview($tempdata);
        $this->set_response($res, REST_Controller::HTTP_OK);

    }


    public function edit_category_post(){
        $id = $this->db->escape_str($this->input->post('id'));
        $category_name = $this->db->escape_str($this->input->post('name'));
        $phones = $this->db->escape_str($this->input->post('phones'));
        $people_per_qr = $this->db->escape_str($this->input->post('people_per_qr'));
        $participants = $this->input->post('participants');
        

        $data = [
            'name' => $this->db->escape_str($category_name),
            'people_per_qr' => $this->db->escape_str($people_per_qr),
            'phones' => ($phones === 'allowed' ? 1: 0),
        ];

        $res = $this->api_model->update_category($data, $id);
        if($res){
            $participants = json_decode($participants,true);
            for($x=0;$x<count($participants);$x++){
                $participant = json_decode($participants[$x],true);
                //$participant['event_id'] = $event_id;
                $participant['category_id'] = $id;      
                $path = $this->generate_qr($participant);
                $participant['qr_img'] = $path;
                if(!$participant['id']){
                    $participant_id = $this->api_model->add_participant($participant);
                }
                $data = $this->api_model->get_participants(['id' => $participant_id]);
                $this->preview($data);
            }
        }
        $this->set_response($res, REST_Controller::HTTP_OK);


    }


    public function get_categories_get(){
        $user_id = $this->db->escape_str($this->input->get('user_id'));
        $res = $this->api_model->get_categories($user_id);
        $category_data = $res['data'];
        for($i = 0; $i < count($category_data); $i++){
            $get_participants = $this->api_model->get_participants(['category_id' => $category_data[$i]->id, 'event_id' => $category_data[$i]->event_id]);
            $category_data[$i]->participants = $get_participants;
        }
        $this->set_response($res, REST_Controller::HTTP_OK);
    }
    
    public function delete_category_delete($id){
        $this->api_model->delete_participants($id);
        $res = $this->api_model->delete_category($id);
        $this->set_response($res, REST_Controller::HTTP_OK);
    }


    // ================= Participants APIs ===================

    public function get_participants_get(){
        $category_id = $this->db->escape_str($this->input->get('category_id'));
        $event_id = $this->db->escape_str($this->input->get('event_id'));

        $participants = $this->api_model->get_participants(['category_id' => $category_id, 'event_id' => $event_id]);

        $this->set_response($participants, REST_Controller::HTTP_OK);
    }

    public function add_participants_post(){
        $participants = $this->input->post('participants');
        $category_id = $this->db->esacape_str($this->input->post('category_id'));
        // $event_id = $this->db->esacape_str($this->input->post('event_id'));

        if($category_id){  
            $participants = json_decode($participants,true);
            for($i=0;$i<count($participants);$i++){
                $participant = json_decode($participants[$i],true);
                //$participant['event_id'] = $event_id;
                $participant['category_id'] = $category_id;
                $res = $this->api_model->add_participant($participant);
            }
        }


        $this->set_response($res, REST_Controller::HTTP_OK);
        
    }


    public function remove_participant_delete($id){
        $res = $this->api_model->remove_participant($id);
        $this->set_response($res, REST_Controller::HTTP_OK);
    }

    // ================= Receptionist APIs ===================

    public function receptionists_get(){
        $res = $this->api_model->get_receptionists();
        $this->set_response($res, REST_Controller::HTTP_OK);
    }


    

    // ================= QR code APIs ===================


    function qr_code_model($participant){
        $participant->category = $this->api_model->get_the_category(['id' => $participant->category_id]);
        $participant->host_data = $this->api_model->get_user(['id' => $participant->category->user_id]);
        $participant->host_data = $participant->host_data['data'][0];
        $qr_path = $this->generate_qr($participant);
        return $qr_path;
    }
    
    function generate_qr($data){
        if($data){
            $this->load->library('ciqrcode');
            //header("Content-Type: image/png");
            $params['data'] = json_encode($data);
            $params['size'] = 5;
            $img_name = $data->number.'-'.$data->name.'.png';
            $path = FCPATH.'images/qr_codes/'.$img_name;
            $params['savename'] = $path;
            $this->ciqrcode->generate($params); 
            return $img_name;
        }else{
            return false;
        }
    }

    function merge_qr($qr_img, $event_card){
        $this->load->library('image_lib');
        $config['image_library'] = 'gd2';

        $config['source_image'] = FCPATH.'images/event_card/'.$event_card;
        $config['wm_overlay_path'] = FCPATH.'images/qr_codes/'.$qr_img; 
        $config['wm_type'] = 'overlay';
        $config['wm_opacity'] = '100';
        $image_name = $event_card.'-'.$qr_img.'.jpg';
        $config['new_image'] =FCPATH.'images/new/'.$image_name;
        // $config['wm_vrt_alignment'] = 'top';
        // $config['wm_hor_alignment'] = 'right';
        // $config['wm_vrt_offset'] = '450';
        // $config['wm_hor_offset'] = '100';
        // $config['dynamic_output'] = true;
        // $config['wm_padding'] = '20';
        // $this->image_lib->clear();
        $this->image_lib->initialize($config);
        $this->image_lib->watermark();
        return $image_name;
    }

    function prepare_cards($event_id){
        $event = $this->admin_model->get_events(['events.id' => $event_id]);
        $event_card = $event[0]->event_card;

        $participants = $this->admin_model->get_participants(['event_id' => $event_id]);

        for($i = 0; $i<count($participants); $i++){
            $qr_img = $participants[$i]->qr_img;
            $img_name = $this->merge_qr($qr_img,$event_card);

            $this->admin_model->update_participants(['id' => $participants[$i]->id], ['card_img' => $img_name]);

        }
    }


    function upload_img($img,$path){
		if ($img["name"] != '') {
            $file_name = $img['name'];
            $size = $img['size'];
            $file_path = $path;
            list($txt, $ext) = explode(".", $file_name);
            $actual_image_name = time() . substr(str_replace(" ", "_", $txt), 5) . "." . $ext;
            $tmp = $img['tmp_name'];
            if (move_uploaded_file($tmp, $file_path . $actual_image_name)) {
                return $actual_image_name;
            } else {
                return false;
            }
        }
	}




/**
 * ======================================================
 * APIs for the Recptionist App
 * =====================================================
 */

function get_rp_events_get(){
    $receptionist_id = $this->db->escape_str($this->input->get('receptionist_id'));
    $events = $this->api_model->get_rp_events($receptionist_id);
    $this->set_response($events, REST_Controller::HTTP_OK);
}

function check_in_get($id){
    $res = $this->api_model->check_in($id);
    $this->set_response($res, REST_Controller::HTTP_OK);

}

/**
 * ======================================================
 * APIs for the Designer App
 * =====================================================
 */


    function get_event_requests_get(){
        $designer_id = $this->db->escape_str($this->input->get('designer_id'));
        $event_requests = $this->api_model->get_event_requests($designer_id);
        $this->set_response($event_requests, REST_Controller::HTTP_OK);
    }

    
    public function submit_design_post(){
        $event_id = $this->db->escape_str($this->input->post('event_id'));
        if($_FILES['eventcard']['size'] > 10){
                    
            $file = $_FILES["eventcard"];
            $filename = $file["name"];
            $file_name_split = explode(".",$filename);
            $ext = end($file_name_split);
            $allowed_ext = array("jpg","png","jpeg","gif","PNG","JPG","JPEG","GIF");
            
            if(in_array($ext,$allowed_ext)){
                //echo $_FILES['eventcard']['name'];exit;
                $img = $this->upload_img($file,"images/event_card/");
                $event_data = [
                    'event_card' => $img,
                    'design_status' => 3
                ];

                $res = $this->api_model->edit_event($event_data, $event_id);
                $this->response($res, REST_Controller::HTTP_OK);
            }else{
                $this->set_response('Invalid file format', REST_Controller::HTTP_NOT_FOUND);
            }
        }
    }

    public function accept_design_post(){
        $design_status = $this->db->escape_str($this->input->post('design_status'));
        $event_id = $this->db->escape_str($this->input->post('event_id'));

        if($design_status == 'accept'){
            $design_status = 1;
        }else if($design_status == 'reject'){
            $design_status = 2;
        }

        $data['design_status'] = $design_status;
        if($design_status == 1){
            $data['designer_appointed'] = date('Y-m-d H:i:s');
        }

        // $condition = [
        //     'id' => $event_id,
        //     'designer_id' => $designer_id
        // ];

        $res = $this->api_model->update_event_request($data, ['event_id' => $event_id]);
        $this->set_response($res, REST_Controller::HTTP_OK);
    }

// ===========================================================================================================


}