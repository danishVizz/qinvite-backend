<?php

class Api_model extends CI_Model{


    // ================== Misc functions ====================

    function response($status, $data, $message){
        $res = [
            'status' => $status,
            'data' => $data,
            'message' => $message
        ];

        return $res;
    }

    function preview($data){
        echo '<pre>'; print_r($data);exit;
    }

    function check_existance($table, $data){
        $res = $this->db->get_where($table, $data);
        if($res->num_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    function update_promocode($data, $code){
        $res = $this->db->update('promo_codes', $data, $code);
        if($res){
            return $this->response(true, [], "Data inserted successfully");
        }else{
            return $this->response(false, [], "Something went wrong!");
        }
    }

    function get_price(){
        $this->db->select('setting_value');
        $res = $this->db->get_where('settings', ['setting_name' => 'price_per_invite'])->row();
        $price = $res->setting_value;
        if($res){
            return $price;
        }else{
            return false;
        }
    }

    function search($keyword){
        $this->db->like('event_name', $keyword);
        $this->db->order_by('id', 'desc');
        $res = $this->db->get('events');
        if($res->num_rows() > 0){
            return $this->response(true, $res->result(), 'Data found');
        }else{
            return $this->response(false, [], 'No data found');
        }
    }

    // ================== User functions ====================

    function add_user($data){
        if(!$this->check_existance('users',['username' => $data['username']])){
            $res = $this->db->insert("users", $data);
            if($res){
                $user_info = $this->db->get_where('users', $data)->result();
                return $this->response(true,$user_info,'Data inserted successfully');
            }else{
                return $this->response(false,[],'Data insertion failed');
            }
        }else{
            return $this->response(false, [], 'ID card number Already exists');
        }
    }

    function get_user($data){
        $this->db->order_by('id', 'desc');
        $user_info = $this->db->get_where('users', $data)->result();
        if($user_info){
            return $this->response(true, $user_info, 'User found');
        }else{
            return $this->response(false, [], "No user found");
        }
    }

    
    function login_user($data){
       
        if(strlen($data['username']) > 0){
            $this->db->group_start();
            $this->db->where("username",$data["username"]);
            $this->db->or_where("phone",$data["username"]);
            $this->db->or_where("email",$data["username"]);
            $this->db->group_end();
            $this->db->where("password",$data["password"]);
            $res = $this->db->get('users');
            if($res->num_rows() > 0){
                $user_info = $res->row();
                return $this->response(true, $user_info, 'Login successful');
            }else{
                return $this->response(false, [], 'Login failed');
            }
        }else{
            return $this->response(false, [], 'Invalid cradentials');
        }

    }

    function update_user($id, $data){

        if($this->check_existance('users', ['id' => $id['id']])){
            $res = $this->db->update('users', $data, $id);
            if($res){
                $new_data = $this->db->get_where('users', $id)->row();
                return $this->response(true, $new_data, 'User updated successfuly');
            }else{
                return $this->response(false, [], 'User update failed');
            }
        }else{
                return $this->response(false, [], "Invalid username");
            }
            
    }


    function delete_user($id){
        if($this->check_existance('users', ['id' => $id])){
            $res = $this->db->delete('users', ['id' => $id]);
            if($res){
                return $this->response(true, [], 'User deleted successfuly');
            }else{
                return $this->response(false, [], 'User deletion failed');
            }
        }else{
            return $this->response(false, [], "Invalid username");
        }
        
    }



    // ================== Designers functions ====================


    function get_designers($where = false){
        if($where){
            $this->db->where($where);
        }
        $this->db->order_by('id', 'desc');
        $res = $this->db->get_where('users', ['role' => 5]);
        if($res->num_rows() > 0){
            return $this->response(true, $res->result(), "Data found successfully");
        }else{
            return $this->response(false, [], "Data not found!");
        }
    }


    function request_designer($data){
        $res = $this->db->insert('event_designer', $data);
        if($res){
            return $this->response(true, [], "Request submitted successfully");
        }else{
            return $this->response(false, [], "Something went wrong!");
        }
        
    }



    // ================== Event functions ====================

    function add_event($data){
        $res = $this->db->insert('events', $data);
        if($res){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }

    function get_events($data){
        $this->db->order_by('id', 'desc');
        $res = $this->db->get_where('events', $data)->result();
        if($res){
            return $this->response(true, $res, 'Events found successfuly');
        }else{
            return $this->response(false, [], 'Events not found');
        }
    }

    function edit_event($data, $id){
        if($this->check_existance('events', ['id' => $id])){
            $this->db->where(['id' => $id]);
                $res = $this->db->update('events', $data);
                if($res){
                    $new_data = $this->db->get_where('events', $id)->result();
                    return $this->response(true, $new_data, "Event updated successfuly");
                }else{
                    return $this->response(false, [], "Event updation faliure!");
                }
        }else{
            return $this->response(false, [], "Event does not exist!");
        }
        
    }
    

    function delete_event($id){
        if($this->check_existance('events',['id' => $id])){
            $res = $this->db->delete('events', ['id' => $id]);
            if($res){
                return $this->response(true, [], 'Event deleted successfuly');
            }else{
                return $this->response(false, [], 'Something went wrong!');
            }
        }else{
            return $this->response(false, [], "Event does not exist");
        }
    }

    // ================== Receptionist functions for the host App ====================

    function add_receptionists($event_id, $receptionists){
        
        for($i=0;$i<count($receptionists); $i++){
            if(!$this->check_existance('event_receptionists', ['event_id' => $event_id, 'receptionist_id' => $receptionists[$i]])){

                $res = $this->db->insert('event_receptionists', ['event_id' => $event_id, 'receptionist_id' => $receptionists[$i]]);
            }
        }

        if($res){
            return true;
        }else{
            return false;
        }
    }

    function update_receptionist($event_id, $receptionists){
        for($i = 0; $i<count($receptionists); $i++){
            if($this->check_existance('event_receptionists', ['event_id' => $event_id, 'receptionist_id' => $receptionists[$i]])){
                $res = $this->db->update('event_receptionists', ['event_id' => $event_id, 'receptionist_id' => $receptionists[$i]]);
            }
        }

        if($res){
            return $this->response(true, [], "Data updated successfully");
        }else{
            return $this->response(false, [], "Something went wrong");
        }
    }

    function get_event_receptionists($id){
        $this->db->select('event_receptionists.event_id, users.*');
        $this->db->where(['event_receptionists.event_id' => $id]);  
        $this->db->join('users', "event_receptionists.receptionist_id = users.id", 'left');
        $this->db->order_by('id', 'desc');
        $res = $this->db->get("event_receptionists");
        if($res->num_rows() > 0){
            return $res->result();
        }else{
            return false;
        }
    }
    
    function get_receptionists($where = false){
        if($where){
            $this->db->where($where);
        }
        $this->db->order_by('id', 'desc');
        $res = $this->db->get_where('users', ['role' => 4, 'status' => 0]);

        if($res->num_rows() > 0){
            return $this->response(true, $res->result(), "Success");
        }else{
            return $this->response(false, [], "Failure");
        }
    }
    
    // ================== Package functions ====================
    
    function get_packages($where = false){
        if($where){
            $this->db->group_start();
            $this->db->where($where);
            $this->db->where(['package_type' => 1]);
            $this->db->group_end();
        }
        $this->db->or_where(['package_type' => 0]);
        $this->db->order_by('id', 'desc');
        $res = $this->db->get('packages')->result();
        if($res){
            return $this->response(true, $res, 'Packages found successfuly');
        }else{
            return $this->response(false, [], 'Packages not found!');
        }

        // return $data;
    }

    function get_event_package($where){
        $this->db->where($where);
        $res = $this->db->get('packages')->row();
        if($res){
            return $res;
        }else{
            return false;
        }
    }
    
    function add_package($data){
        $res = $this->db->insert('packages', $data);
        if($res){
            $package_id = $this->db->insert_id();
            return $package_id;
        }else{
            return $this->response(false, [], "Something went wrong!");
        }
    }
   
    // ================== Category functions ====================

    function add_category($data){
        // $this->preview($data);
        $res = $this->db->insert('categories', $data);
        
        if($res){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }

    function get_categories($id){
        $this->db->where('user_id', $id);
        $this->db->where('type', 1);
        $this->db->order_by('id', 'desc');
        $res = $this->db->get('categories');
        if($res->num_rows() > 0){
            return $this->response(true, $res->result(), "Categories found");
        }else{
            return $this->response(false, [], "No categories found");
        }
    }

    function get_the_category($where=false){
        if($where){
            $this->db->where($where);
        }

        $res = $this->db->get('categories');
        if($res->num_rows() > 0){
            return $res->row();
        }else{
            return false;
        }
    }

    function delete_category($id){
        if($this->check_existance('categories', ['id' => $id])){
            $res = $this->db->delete('categories', ['id' => $id]);

            if($res){
                return $this->response(true, [], "Category deleted successfuly");
            }else{
                return $this->response(false, [], "Something went wrong");
            }
        }else{
            return $this->response(false, [], "Invalid category");
        }
    }

    function update_category($data, $id){
        if($this->check_existance('categories', ['id' => $id])){
            $res = $this->db->update('categories', $data);
            if($res){
                // $new_data = $this->db->get_where('categories', ['id' => $id])->result();
                // return $this->response(true, $new_data, 'Category updated successfuly');
                return true;
            }else{
                // return $this->response(false, [], 'Something went wrong');
                return false;
            }
        }else{
            //return $this->response(false, [], 'Invalid category');
            return false;
        }
    }

    function add_event_category($data){
        $res = $this->db->insert('event_category', $data);
        if($res){
            return $this->response(true, [], "Data inserted successfully");
        }else{
            return $this->response(false, [], "Something went wrong!");
        }
    }

    // ================== Participants functions ====================

    function add_participant($data){
        if(!empty($data)){
            $this->db->insert("participants",$data);
            if($this->db->affected_rows() > 0){
                return $this->db->insert_id();
            }else{
                return $this->response(true, [], 'Something went wrong!');
            }
        }else{
            return $this->response(true, [], 'No participants');
        }
    }

    function get_participants($where=false){ 
        if($where){
            $this->db->where($where);
        }
        $this->db->order_by('id', 'desc');
        $res = $this->db->get('participants');
        if($res->num_rows() > 0){
                return $res->result();
        }else{
            return array();
        }
    }

    function delete_participants($id){
        $res = $this->db->delete('participants', ['category_id' => $id]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    function remove_participant($id){
        $res = $this->db->delete('participants', ['id' => $id]);
        if($res){
            return $this->response(true, [], 'Participant removed successfully');
        }else{
            return $this->response(false, [], 'Something went wrong!');
        }
    }


    function update_participant($where=false, $data){
        if($where){
            $this->db->where($where);
        }

        $res = $this->db->update('participants', $data);

        if($res){
            return true;
        }else{
            return false;
        }
    }
     
    // ================== Card functions ====================



    // ================== QR code functions ====================


    /**
     * ===================================================
     *  Functions for Receptionists App
     * ===================================================
    */


    function get_rp_events($id){
        $this->db->select('event_receptionists.receptionist_id, events.id, events.event_name, events.event_date, events.event_address, events.no_of_receptionists, events.event_card, events.event_status');
        $this->db->where(['event_receptionists.receptionist_id' => $id]);  
        $this->db->join('events', "event_receptionists.event_id = events.id", 'left');
        $this->db->order_by('id', 'desc');
        $events = $this->db->get("event_receptionists")->result();

        foreach($events as $event){
            $participants = $this->db->get_where('participants', ['event_id' => $event->id])->result();
            $event->participants = $participants;
        }
        
        if($events){
            return $this->response(true, $events, "Events found successfully");
        }else{
            return $this->response(false, [], "No data found");
        }
    }
    
    function check_in($id){
        $res = $this->db->update('participants', ['check_in' => 1], ['id' => $id]);

        if($res){
            return $this->response(true, [], "Participants checked in successfully");
        }else{
            
        }
    }

    /**
     * ===================================================
     *  Functions for Designer App
     * ===================================================
    */

    function get_event_requests($id){
        $this->db->select('event_designer.*, events.event_name, events.event_date, users.first_name, users.last_name, users.phone');
        $this->db->where(['event_designer.designer_id' => $id ]);
        $this->db->join('users', 'users.id = event_designer.user_id', 'left');
        $this->db->join('events', 'events.id = event_designer.event_id', 'left');
        $this->db->order_by('events.id', 'desc');
        $events = $this->db->get('event_designer');
        if($events->num_rows() > 0){
            return $this->response(true, $events->result(), "Requests found");
        }else{
            return $this->response(false, [], "No requests found");
        }

    }

    function update_event_request($data, $where){
        $res = $this->db->update('event_designer', $data, $where);

        if($res){
            return $this->response(true, [], "Request is accepted by designer");
        }else{
            return $this->response(false, [], "Request is rejected by designer");
        }
    }







}