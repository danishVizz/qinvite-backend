<?php

class Admin_model extends CI_Model{

    function check_existance($table, $data,$exclude=false){
        foreach($data as $k=>$v){
            $this->db->where($k,$v);
        }
        if($exclude){
            foreach($exclude as $key=>$val){
                $this->db->where($key."!=",$val);
            }
        }
        $res = $this->db->get($table);
        //echo $this->db->last_query();exit;
        if($res->num_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    // ========== Users ==============

    function login_user($data){
       
        if(strlen($data['username']) > 0){
            $this->db->group_start();
            $this->db->where("username",$data["username"]);
            $this->db->or_where("phone",$data["username"]);
            $this->db->or_where("email",$data["username"]);
            $this->db->group_end();
            $this->db->where("password",$data["password"]);
            $this->db->group_start();
            $this->db->where("role", 0);
            $this->db->or_where("role", 1);
            $this->db->or_where("role", 3);
            $this->db->group_end();
            $res = $this->db->get('users');
            if($res->num_rows() > 0){
                $user_info = $res->row();
                return $user_info;
            }else{
                return false;
            }
        }else{
            return false;
        }

    }

    function insert_user($data){
        $res = $this->db->insert('users', $data);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    function get_users($where = false){
        if($where){
            foreach($where as $k=>$v){
                $this->db->where($k,$v);
            }
        }
        $user_data = $this->db->get('users');
        if($user_data->num_rows() > 0){
            return $user_data->result();
        }else{
            return array();
        }
    }
    
    function update_user($data,$user_id){
        //echo '<pre>'; print_r($data); print_r($user_id);exit;
        if(!empty($data) && $user_id > 0){
            $this->db->update("users",$data,array("id"=>$user_id));
            echo $this->db->last_query();exit;
            if($this->db->affected_rows() > 0){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
    function delete_user($id){
        $get_details = $this->db->get_where("users","id = $id");
        if($get_details->num_rows() > 0){
            $res = $this->db->delete('users', ['id' => $id]);
        }
        return ($res)? true : false;
    }


     // ========== Events ==============
    function get_events($where = false){
        $this->db->select("events.*, users.first_name, users.last_name, packages.package_name");
        if($where){
            $this->db->where($where);   
        }
        $this->db->join('users', 'events.user_id = users.username', 'left');
        $this->db->join('packages', 'events.package_id = packages.id', 'left');
        $event_data = $this->db->get('events');
        if($event_data->num_rows() > 0){
            return $event_data->result();
        }else{
            return array();
        }
    }

    function add_event($data){
        $res = $this->db->insert('events', $data);

        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    function update_event($data, $id){
        $res = $this->db->update('events', $data, ['id' => $id]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    function delete_event($id){
       $event = $this->db->get_where('events', ['id' => $id]);

       if($event->num_rows() > 0){
           $res = $this->db->delete('events', ['id' => $id]);

           if($res){
               return true;
           }else{
               return false;
           }
       }else{
           return false;
       }
    }

     // ========== Packages ==============

    function get_packages($where = false){
        $this->db->select("packages.*,users.first_name,users.last_name");
        if($where){
            $this->db->where($where);
        }
        $this->db->join("users","packages.user_id = users.username",'left');
        $package_data = $this->db->get('packages');
        if($package_data->num_rows() > 0){
            return $package_data->result();
        }else{
            return array();
        }
    }

    function add_package($data){
        $res = $this->db->insert('packages', $data);
        return ($res ? true : false );
    }

    function delete_package($id){
        $get_details = $this->db->get_where('packages', ['id' => $id]);
        if($get_details->num_rows() > 0){
           $res = $this->db->delete('packages', ['id' => $id]);
        }

        return ($res ? true : false);
    }

    function update_package($data, $id){
        $res = $this->db->update('packages', $data, ['id' => $id]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

     // ========== Promocodes ==============

    function get_promocodes($where = false){
        $this->db->select('promo_codes.*, events.event_name');
        if($where){
            $this->db->where($where);
        }
        $this->db->join('events', 'promo_codes.event_id = events.id', 'left');
        $promocodes_data = $this->db->get('promo_codes');
        if($promocodes_data->num_rows() > 0){
            return $promocodes_data->result();
        }else{
            return array();
        }
    }

    function add_promocode($data){
        $res = $this->db->insert('promo_codes', $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    function delete_promocode($id){
        $res = $this->db->delete('promo_codes', ['id' => $id]);

        if($res){
            return true;
        }else{
            return false;
        }
    }

     // ========== Categories ==============

    function create_category($data){
        $res = $this->db->insert('categories', $data);

        if($res){
            return true;
        }else{
            return false;
        }
    }

    function get_category($where=false){
        if($where){
            $this->db->where($where);
        }

        $res = $this->db->get('categories');
        if($res->num_rows() > 0){
            return $res->result();
        }else{
            return false;
        }
    }

    function get_category_listing(){
        $this->db->select('categories.*, users.first_name, users.last_name, users.role');
        $this->db->join('users', 'users.id = categories.user_id', 'left');
        $data = $this->db->get('categories');

        if($data->num_rows() > 0){
            return $data->result();
        }else{
            return array();
        }
    }

    function update_category($data, $id){ 
        $res = $this->db->update('categories', $data, ['id' => $id]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    function delete_category($id){
        $res = $this->db->delete('categories', ['id' => $id]);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    function save_settings($key,$value){
        $check = $this->check_existance("settings",array("setting_name"=>$key));
        if($check){
            $this->db->update("settings",array("setting_value"=>$value),array("setting_name"=>$key));
        }else{
            $this->db->insert("settings",array("setting_value"=>$value,"setting_name"=>$key));
        }
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    function get_settings(){
        $res = $this->db->get('settings');
        if($res->num_rows() > 0){
            return $res->result_array();
        }else{
            return false;
        }
    }

    function get_participants($where=false){ 
        if($where){
            $this->db->where($where);
        }

        $res = $this->db->get('participants');
        if($res->num_rows() > 0){
            return $res->result();
        }else{
            return array();
        }
    }

    function update_participants($where=false, $data){
        if($where){
            $this->db->where($where);
        }

        $res = $this->db->update('participants', $data);

        if($res){
            return true;
        }else{
            return false;
        }
    }
    

}